package com.mobiquity.controller;

import static com.mobiquity.packer.Packer.pack;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;

import org.slf4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mobiquity.exception.APIException;

@RestController
@RequestMapping(path = { "/api/package" })
public class PackageController {

	private Logger log = getLogger(PackageController.class);

	@GetMapping(path = "/calculatePackage")
	public String calculatePackage(@RequestParam(name = "filePath", required = true) String filePath) throws APIException, IOException {

		log.info("calculatePackage api initiated for filePath {}", filePath);
		String response = pack(filePath);
		System.out.print(response);
		return response;
	}

}
