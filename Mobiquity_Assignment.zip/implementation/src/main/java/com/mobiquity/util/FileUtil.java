package com.mobiquity.util;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.Files.readAllLines;
import static java.nio.file.Paths.get;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import org.slf4j.Logger;

import com.mobiquity.exception.APIException;

public class FileUtil {

	private static final Logger log = getLogger(FileUtil.class);

	private FileUtil() {
	}

	public static List<String> readFileLines(final String pathPrefix) throws IOException, APIException {
		try {
			Path path = get(pathPrefix);
			return readAllLines(path, UTF_8);
		} catch (Exception e) {
			log.error("Exception occurred while reading the file {}", e.getMessage(), e);
			throw new APIException("Exception occurred while reading the file", e);
		}
	}

}