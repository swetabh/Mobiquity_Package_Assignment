package com.mobiquity.model;

public class PackageDetail implements Comparable<PackageDetail> {

	private String index;
	private int maxWeight;
	private Double currentWeight;
	private Double price;

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public int getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(int maxWeight) {
		this.maxWeight = maxWeight;
	}

	public Double getCurrentWeight() {
		return currentWeight;
	}

	public void setCurrentWeight(Double currentWeight) {
		this.currentWeight = currentWeight;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public int compareTo(PackageDetail o) {
		return this.currentWeight.compareTo(o.getCurrentWeight());
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PackageDetail [index=").append(index).append(", maxWeight=").append(maxWeight)
				.append(", currentWeight=").append(currentWeight).append(", price=").append(price).append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currentWeight == null) ? 0 : currentWeight.hashCode());
		result = prime * result + ((index == null) ? 0 : index.hashCode());
		result = prime * result + maxWeight;
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PackageDetail other = (PackageDetail) obj;
		if (currentWeight == null) {
			if (other.currentWeight != null)
				return false;
		} else if (!currentWeight.equals(other.currentWeight))
			return false;
		if (index == null) {
			if (other.index != null)
				return false;
		} else if (!index.equals(other.index))
			return false;
		if (maxWeight != other.maxWeight)
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		return true;
	}

}