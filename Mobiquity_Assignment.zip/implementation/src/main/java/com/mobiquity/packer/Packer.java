package com.mobiquity.packer;

import static com.mobiquity.util.FileUtil.readFileLines;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.valueOf;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mobiquity.exception.APIException;
import com.mobiquity.model.PackageDetail;

@RestController
@RequestMapping(path = { "/api/packer" })
public class Packer {

	private static final Logger log = getLogger(Packer.class);
	
	private Packer() {
	}

	public static String pack(String filePath) throws APIException, IOException {

		StringBuilder finalOutput = new StringBuilder();
		List<String> allLines = readFileLines(filePath);
		// Check if the file has content
		if (allLines.isEmpty()) {
			String errorMsg = "File content is empty";
			log.error(errorMsg);
			return errorMsg;
		}
		
		try {
			for (String input : allLines) {

				CopyOnWriteArrayList<PackageDetail> packageList  = new CopyOnWriteArrayList<>();
				PackageDetail packDtl;
				String packages = input.split(":")[1].trim();
				String[] packageArray = packages.split(" ");
				for (String pack : packageArray) {
					String[] pkg = pack.split(",");
					packDtl = new PackageDetail();
					packDtl.setMaxWeight(valueOf(input.split(":")[0].trim()));
					packDtl.setIndex(pkg[0].substring(1));
					packDtl.setCurrentWeight(parseDouble(pkg[1]));
					packDtl.setPrice(parseDouble(pkg[2].substring(1, pkg[2].length() -1)));
					packageList.add(packDtl);
				}
				PackageDetail[] finalPackageArray = new PackageDetail[packageList.size()];
				finalPackageArray = packageList.toArray(finalPackageArray);

		        String finalIndex = "-";
				double maxPackageWeight = parseDouble(input.split(":")[0].trim());

				//Check if maxweight is more than 100
				if (maxPackageWeight <= 100) {
					double finalMaxValue = 0.0;

					// Check if the input is valid
					if ("".equalsIgnoreCase(input)) {
						log.error("Please enter a valid input");
					} else if (finalPackageArray.length == 1) {
						// If there is one line in the file
						PackageDetail finalPackage = finalPackageArray[0];
						double currSum = finalPackage.getCurrentWeight();
						if (currSum < maxPackageWeight) {
							finalIndex = finalPackage.getIndex();
						}
					}
	
					double initialSum;
					double currSum;
					double tempSum;
					double currVal;
					for (int i = 0; i < finalPackageArray.length; i++) {
						currSum = finalPackageArray[i].getCurrentWeight();
						currVal = finalPackageArray[i].getPrice();
						if (currSum < maxPackageWeight && currVal >= finalMaxValue) {
							finalMaxValue = currVal;
							finalIndex = finalPackageArray[i].getIndex();
						}
						for (int j = i + 1; j < finalPackageArray.length; j++) {
							tempSum = finalPackageArray[i].getCurrentWeight() + finalPackageArray[j].getCurrentWeight();
							initialSum = tempSum;
							if (tempSum <= maxPackageWeight) {
								currVal = finalPackageArray[i].getPrice() + finalPackageArray[j].getPrice();
								currSum = finalPackageArray[i].getCurrentWeight()
										+ finalPackageArray[j].getCurrentWeight();
								if (currSum <= initialSum && tempSum < maxPackageWeight && currVal >= finalMaxValue) {
									finalMaxValue = currVal;
									finalIndex = finalPackageArray[i].getIndex() + ","
											+ finalPackageArray[j].getIndex();
								}
							}
						}
					}
					finalOutput.append(finalIndex + "\n");
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred while parsing the file {}", e.getMessage(), e);
			throw new APIException("Exception occurred while parsing the file", e);
		}
		return finalOutput.toString();
	}
}
