package com.mobiquity;

import static com.mobiquity.packer.Packer.pack;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.mobiquity.exception.APIException;
import com.mobiquity.util.FileUtil;

@RunWith(MockitoJUnitRunner.class)
public class PackerTest {

	@Mock
	private FileUtil fileUtil;

	@Test(expected = APIException.class)
	public void testEmptyFileException() throws APIException, IOException {

		pack("");
	}

	@Test(expected = APIException.class)
	public void testWrongFileException() throws APIException, IOException {

		pack("src/test/resources/wrong_file.txt");
	}

	@Test(expected = APIException.class)
	public void testWrongFormatFileException() throws APIException, IOException {

		pack("src/test/resources/sample_data_file_invalid_format.txt");
	}

	@Test
	public void testFileWithNoLinesSuccess() throws APIException, IOException {

		String response = pack("src/test/resources/empty_file.txt");
		assertNotNull(response);
		assertEquals("File content is empty", response);
	}

	@Test
	public void testFileWithOneLineSuccess() throws APIException, IOException {

		String response = pack("src/test/resources/sample_data_file_one_line.txt");
		assertNotNull(response);
		assertEquals(1, response.split("\n").length);
		System.out.println(response);
	}

	@Test
	public void testFileWithFourLineSuccess() throws APIException, IOException {

		String response = pack("src/test/resources/sample_data_file_four_lines.txt");
		assertNotNull(response);
		assertEquals(4, response.split("\n").length);
	}

}