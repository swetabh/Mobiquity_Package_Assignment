package com.mobiquity;

import static com.mobiquity.util.FileUtil.readFileLines;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.mobiquity.exception.APIException;

@RunWith(MockitoJUnitRunner.class)
public class FileUtilTest {

	@Test(expected = APIException.class)
	public void testFileNotFoundException() throws APIException, IOException {

		readFileLines("src/test/resources/wrong_file_name.txt");
	}

	@Test
	public void testReadEmptyText() throws APIException, IOException {

		List<String> fileLines = readFileLines("src/test/resources/empty_file.txt");
		assertNotNull(fileLines);
		assertEquals(0, fileLines.size());
	}

	@Test
	public void testReadInvalidFormatFileText() throws APIException, IOException {

		List<String> fileLines = readFileLines("src/test/resources/sample_data_file_invalid_format.txt");
		assertNotNull(fileLines);
	}

	@Test
	public void testReadSampleOneLineText() throws APIException, IOException {

		List<String> fileLines = readFileLines("src/test/resources/sample_data_file_one_line.txt");
		assertNotNull(fileLines);
		assertEquals(1, fileLines.size());
	}

	@Test
	public void testReadSampleFourLinesText() throws APIException, IOException {

		List<String> fileLines = readFileLines("src/test/resources/sample_data_file_four_lines.txt");
		assertNotNull(fileLines);
		assertEquals(4, fileLines.size());
	}

}